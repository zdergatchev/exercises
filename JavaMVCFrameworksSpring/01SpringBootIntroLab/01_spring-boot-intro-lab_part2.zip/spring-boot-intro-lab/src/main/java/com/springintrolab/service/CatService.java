package com.springintrolab.service;

import com.springintrolab.models.CatModel;
import org.springframework.stereotype.Service;

@Service
public interface CatService {
    void buy(CatModel catModel);
}
