package com.springintrolab.serviceImpl;

import com.springintrolab.entityes.Cat;
import com.springintrolab.models.CatModel;
import com.springintrolab.repository.CatRepository;
import com.springintrolab.service.CatService;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class CatServiceImpl implements CatService {

    @Autowired
    private ModelMapper modelMapper;

    @Autowired
    private CatRepository catRepository;

    @Override
    public void buy(CatModel catModel) {
        Cat cat = this.modelMapper.map(catModel, Cat.class);
        this.catRepository.save(cat);
    }
}
