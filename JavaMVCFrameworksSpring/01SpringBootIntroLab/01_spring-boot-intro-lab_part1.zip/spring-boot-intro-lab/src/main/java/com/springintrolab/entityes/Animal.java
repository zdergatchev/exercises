package com.springintrolab.entityes;

public interface Animal {

    String getName();

    void setName(String name);
}
