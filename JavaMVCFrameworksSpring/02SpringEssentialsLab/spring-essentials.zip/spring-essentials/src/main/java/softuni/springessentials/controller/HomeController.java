package softuni.springessentials.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import softuni.springessentials.model.User;

@Controller
public class HomeController {

    @GetMapping("/")
    public String index(Model model){
        model.addAttribute("view", "home/index");
        model.addAttribute("title", "Home Page");
        model.addAttribute("user", new User(4L, "pesho"));
        return "base-layout";
    }

//    @GetMapping("/buy/{id}")
//    public String buy(@PathVariable() Long id){
//        System.out.println(id);
//        return "redirect:/";
//    }
}
