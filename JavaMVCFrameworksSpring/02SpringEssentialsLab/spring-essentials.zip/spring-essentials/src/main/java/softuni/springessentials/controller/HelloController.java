package softuni.springessentials.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.view.RedirectView;
import softuni.springessentials.model.User;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

@Controller
public class HelloController {

//    @GetMapping("/hello")
//    public String hello(Model model){
//        model.addAttribute("name", "pesho");
//        return  "block";
//    }

//    @GetMapping("/hello")
//    public String hello(Model model, HttpSession httpSession){
//        httpSession.setAttribute("name", "pesho");
//        return  "block";
//    }

//    @GetMapping("/hello")
//    public String hello(Model model){
//        User user = new User(35L, "pesho");
//        model.addAttribute("user", user);
//        return  "block";
//    }

//    public ModelAndView hello(){
//        User user = new User(35L, "pesho");
//        ModelAndView mav = new ModelAndView("block");
//        mav.addObject("user", user);
//        return mav;
//    }

//    @GetMapping("/hello")
//    public ModelAndView hello(){
//        ModelAndView mav = new ModelAndView("block");
//        RedirectView view =  new RedirectView("/pesho");
//        mav.setView(view);
//        return mav;
//    }

//    @GetMapping("/hello")
//    public String hello(Model model){
//        return "block";
//    }

    @GetMapping("/hello/index")
    public String hello(Model model){
        model.addAttribute("id", 5);
        return "block";
    }

    @GetMapping("/hello/form")
    public String hello(){
        return "form";
    }
}
