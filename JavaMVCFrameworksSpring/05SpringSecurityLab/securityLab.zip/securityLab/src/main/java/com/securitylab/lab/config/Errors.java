package com.securitylab.lab.config;

public class Errors {

    public static final String INVALID_CREDENTIONALS = "Invalid Credentials";
}
