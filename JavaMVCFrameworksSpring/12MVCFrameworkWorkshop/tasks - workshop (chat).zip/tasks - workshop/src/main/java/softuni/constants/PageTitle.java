package softuni.constants;

public interface PageTitle {
    String HomePageTitle = "Home";
}
