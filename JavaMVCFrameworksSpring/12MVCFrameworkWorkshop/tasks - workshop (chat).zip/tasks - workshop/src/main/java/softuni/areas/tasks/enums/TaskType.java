package softuni.areas.tasks.enums;

public enum TaskType {
    Web,
    Game,
    Embedded,
    Mobile,
    Application;
}
