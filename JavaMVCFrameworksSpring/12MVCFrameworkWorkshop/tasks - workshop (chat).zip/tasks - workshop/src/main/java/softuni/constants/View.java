package softuni.constants;

public interface View {
    String HomeIndexView = "home/index";
    String BaseLayoutView = "base-layout";
}
