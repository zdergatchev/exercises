package springthymeleafadvancedlab.softuni.models;


import springthymeleafadvancedlab.softuni.annotations.ValidDouble;

import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

public class WhiskeyBindingModel {

    @NotBlank(message = "Name should not be blank")
    @Size(min = 5, max = 20)
    private String name;

    @ValidDouble()
    //@Pattern(regexp = "\\d+\\.?\\d+", message = "Invalid number")
    @Min(value = 10, message = "The whiskey cannot be that cheap")
    private Double price;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Double getPrice() {
        return price;
    }

    public void setPrice(Double price) {
        this.price = price;
    }
}
